/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Madbr
 */
public abstract class Part {
    
    //properties
    private int id;
    private String name;                
    private double price;
    private int stock;
    private int min;    
    private int max;
    
    //constructor
    public Part(){
        id = 0;
        name = "";
        price = 0;
        stock = 0;
        min = 0;
        max = 0;
    }
    
    public Part(int _id, String _name, double _price, int _stock, int _min, int _max){
        id = _id;
        name = _name;
        price = _price;
        stock = _stock;
        min = _min;
        max = _max;
    }
    
    //getters and setters
    public void setId(int _id){
       id = _id;
    }
    
    public int getId(){
        return id;
    }
    
    public void setName(String _name){
        name = _name;
    }
    
    public String getName(){
        return name;
    }
    
    public void setPrice(double _price){
        price = _price;
    }
    
    public double getPrice(){
        return price;
    }
    
    public void setStock(int _stock){
        stock = _stock;
    }
    
    public int getStock(){
        return stock;
    }
    
    public void setMin(int _min){
        min = _min;
    }
    
    public int getMin(){
        return min;
    }
    
    public void setMax(int _max){
        max = _max;
    }
    
    public int getMax(){
        return max;
    }
  
    public void Display(){
        System.out.println("ID:" + id);
        System.out.println("name:" + name);
        System.out.println("price:" + price);
        System.out.println("stock:" + stock);
        System.out.println("min:" + min);
        System.out.println("max:" + max);
    }
    /*
    public static void main(String[] args) {
     Part p1 = new Part(12,"boop",1.0,2,4,5);
     p1.Display();
    }
*/
}
