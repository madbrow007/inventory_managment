/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Madbr
 */
public class Outsourced extends Part {
    
     private String companyName;
    
    public Outsourced(){
        super();
        companyName = "";
    }
    
    public Outsourced(int _id, String _name, double _price, int _stock, int _min, int _max, String _companyName){
        super(_id, _name, _price, _stock, _min, _max);
        companyName = _companyName;
    }
    
    public void setCompanyName(String _companyName){
        companyName = _companyName;
    }
    
    public String getCompanyName(){
        return companyName;
    }
}
