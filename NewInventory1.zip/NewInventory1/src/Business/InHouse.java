/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Madbr
 */
public class InHouse extends Part{
    
    private int machineId;
    
    public InHouse(){
        super();
        machineId = 0;
    }
    
    public InHouse(int _id, String _name, double _price, int _stock, int _min, int _max, int _machineId){
        super(_id, _name, _price, _stock, _min, _max);
        machineId = _machineId;
    }
    
    public void setMachineId(int _machineId){
        machineId = _machineId;
    }
    
    public int getMachineId(){
        return machineId;
    }
}
