/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import javafx.collections.*;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 *
 * @author Madbr
 */
public class Inventory {
    
    //properties
    private ObservableList<Part> allParts = FXCollections.observableArrayList();
    private ObservableList<Product> allProducts = FXCollections.observableArrayList();
    
    //methods
    public void addPart(Part newPart){
        allParts.add(newPart);
    }
    
    public void addProduct(Product newProduct){
        allProducts.add(newProduct);
    }
    
    public Part lookupPart(int partId){
        
       int index = 0;
       for (Part eachPart : allParts){
           
           if (partId == eachPart.getId()){
               index = allParts.indexOf(eachPart);
               break;
           }
       }  
        
       return allParts.get(index);   
    }
   
    
    public Product lookupProduct(int productId){
        int index = 0;
        for (Product eachProduct : allProducts){
            
            if (productId == eachProduct.getId()){
                index = allProducts.indexOf(eachProduct);
                break;
            }         
        }
        return allProducts.get(index);
    }
    
    
    public ObservableList<Part> lookupPart(String partName){
        getAllParts();
        
        CharSequence nameChar = partName;
        ObservableList<Part> searchResult = FXCollections.observableArrayList();
        
        for (Part eachPart : allParts){
            if (eachPart.getName().contains(nameChar)) {
                searchResult.add(eachPart);
            }
        }
        
        return searchResult;
    }
    
    public ObservableList<Product> lookupProduct(String productName){
         getAllProducts();
        
        CharSequence nameChar = productName;
        ObservableList<Product> searchResult = FXCollections.observableArrayList();
        
        for (Product eachProduct : allProducts){
            if (eachProduct.getName().contains(nameChar)) {
                searchResult.add(eachProduct);
            }
        }
        return searchResult;
    }
    
    
    public void updatePart(int index, Part selectedPart){
        allParts.set(index, selectedPart);
    }
    
    
    public void updateProduct(int index, Product selectedProduct){
         allProducts.set(index, selectedProduct);
    }
    
    
    public boolean deletePart(Part selectedPart){
       allParts.remove(allParts.indexOf(selectedPart));
       
       return true;
    }
    
    public boolean deleteProduct(Product selectedProduct){
       allProducts.remove(allProducts.indexOf(selectedProduct));
       
       return true;
    }
    

    public ObservableList<Part> getAllParts(){
    
        return allParts;
    }
    
    public ObservableList<Product> getAllProducts(){
       
        return allProducts;
    }
}
