/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newinventory1;

import Business.InHouse;
import Business.Inventory;
import Business.Outsourced;
import Business.Part;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Madbr
 */
public class ModifyPartScreenController implements Initializable {
    
    @FXML
    private RadioButton inHouseRB;
    @FXML
    private RadioButton outRB;
    @FXML
    private TextField idTF;
    @FXML
    private TextField nameTF;
    @FXML
    private TextField invTF;
    @FXML
    private TextField pcTF;
    @FXML
    private TextField maxTF;
    @FXML
    private TextField minTF;
    @FXML
    private Label cNameLbl;
    @FXML
    private Label mIDLbl;
    @FXML
    private TextField mIDTF;
    @FXML
    private TextField cNameTF;
    @FXML
    private Button saveBtn;
    @FXML
    private Button cancelBtn;
    
    private InHouse selectedPartI; 
    
    private Outsourced selectedPartO; 
    
    private int selectedIndex;
    
    private Inventory i1 = new Inventory();
    
    private Stage oldWindow;
    
    Alert minAlert = new Alert(Alert.AlertType.ERROR);
    
    Alert delAlert = new Alert(Alert.AlertType.CONFIRMATION);

    ButtonType yes = new ButtonType("Yes");

    ButtonType no = new ButtonType("No");

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO  
   
        delAlert.setTitle("Are You Sure?");
        delAlert.setHeaderText("Confirm cancellation or deletion");

        delAlert.getButtonTypes().setAll(yes, no);
   
        minAlert.setTitle("Error Dialog");
        minAlert.setHeaderText("Minimum exceeds Maximum Error!");
        minAlert.setContentText("The minimum field entered is greater than the maximum field! Please enter smaller value!");
       
    }    
    
    @FXML
    public void handleButtonAction(ActionEvent ev) throws IOException
    {
        //Cancel Button
           if( ev.getSource() == cancelBtn){
              Optional<ButtonType> answer = delAlert.showAndWait();
              if (answer.get() == yes){
              Stage window = (Stage) ((Node) ev.getSource()).getScene().getWindow();
              window.close();
            }
              else{}
           }
           
             if( ev.getSource() == outRB){
               inHouseRB.setSelected(false); 
               cNameLbl.setVisible(true);
               cNameTF.setVisible(true);
               mIDLbl.setVisible(false);
               mIDTF.setVisible(false);   
            }
             
            if( ev.getSource() == inHouseRB){
              outRB.setSelected(false);
              mIDLbl.setVisible(true);
              mIDTF.setVisible(true);
              cNameLbl.setVisible(false);
              cNameTF.setVisible(false);   
            }
            
            if( ev.getSource() == saveBtn){
                 
                //adding new part, not updating it
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));

                Parent parentName = fxmlLoader.load();

                Scene sceneName = new Scene(parentName);

                FXMLDocumentController mainScreen = fxmlLoader.getController();

                int id = Integer.parseInt(idTF.getText());
                String name = nameTF.getText();
                Double price = Double.parseDouble(pcTF.getText());
                int stock = Integer.parseInt(invTF.getText());
                int min = Integer.parseInt(minTF.getText());
                int max = Integer.parseInt(maxTF.getText());

                if (min > max) {
                    minAlert.showAndWait();
                } else {

                    if (inHouseRB.isSelected()) {
                        int machineID = Integer.parseInt(mIDTF.getText());

                        i1.updatePart(selectedIndex, new InHouse(id, name, price, stock, min, max, machineID));

                        mainScreen.setList(i1.getAllParts());
                    } else {
                        String companyName = cNameTF.getText();
                        i1.updatePart(selectedIndex, new Outsourced(id, name, price, stock, min, max, companyName));

                        mainScreen.setList(i1.getAllParts());
                    }
                    

                    oldWindow.close();

                    Stage window = (Stage) ((Node) ev.getSource()).getScene().getWindow();
                    window.setScene(sceneName);
                    window.show();
                }
            }
    }
     
    public void setSelected(int index, Part part){
        selectedIndex = index;
     
        if (part.getClass().getName().contains("InHouse")){
             inHouseRB.setSelected(true);
             outRB.setSelected(false);
             mIDLbl.setVisible(true);
             mIDTF.setVisible(true);
             cNameLbl.setVisible(false);
             cNameTF.setVisible(false); 
             
             selectedPartI = (InHouse) part;
             mIDTF.setText(Integer.toString(selectedPartI.getMachineId()));
        }
        else{
             outRB.setSelected(true);
             inHouseRB.setSelected(false); 
             cNameLbl.setVisible(true);
             cNameTF.setVisible(true);
             mIDLbl.setVisible(false);
             mIDTF.setVisible(false);
             
             selectedPartO = (Outsourced) part;
             cNameTF.setText(selectedPartO.getCompanyName());
        }
        
       idTF.setText(Integer.toString(part.getId()));
       nameTF.setText(part.getName());
       invTF.setText(Integer.toString(part.getStock()));
       pcTF.setText(Double.toString(part.getPrice()));
       maxTF.setText(Integer.toString(part.getMax()));
       minTF.setText(Integer.toString(part.getMin()));
    
    }
 
    
    public void setList(ObservableList<Part> newAllParts){
        for (Part eachPart : newAllParts){
            
            i1.addPart(eachPart);
    }
    }
    
    public void getOldWindow(Stage window){
         oldWindow = window;
     } 
    
    
}
