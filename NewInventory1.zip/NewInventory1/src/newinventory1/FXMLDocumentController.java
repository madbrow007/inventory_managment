/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newinventory1;

import Business.*;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.collections.*;
import javafx.collections.FXCollections;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;



/**
 *
 * @author Madbr
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private Button prtSBtn;
    @FXML
    private Button prtAddBtn;
    @FXML
    private Button prtModBtn;
    @FXML
    private Button prtDelBtn;
    @FXML
    private Button proSBtn;
    @FXML
    private Button proModBtn;
    @FXML
    private Button proDelBtn;
    @FXML
    private TextField prtTF;
    @FXML
    private TextField proTF;
    @FXML
    private Button eBtn;
    @FXML
    private Button proAddBtn;
    @FXML
    private TableView<Part> partTableView;
    @FXML
    private TableColumn<Part, Integer> ptIdCol;
    @FXML
    private TableColumn<Part, String> ptNameCol;
    @FXML
    private TableColumn<Part, Integer> ptInvCol;
    @FXML
    private TableColumn<Part, Double> ptPriceCol;
    @FXML
    private TableView<Product> proTableView;
    @FXML
    private TableColumn<Product, Integer> proIdCol;
    @FXML
    private TableColumn<Product, String> proNameCol;
    @FXML
    private TableColumn<Product, Integer> proInvCol;
    @FXML
    private TableColumn<Product, Double> proPriceCol;
    
    private Inventory i1 = new Inventory();
    
    Alert delAlert = new Alert(Alert.AlertType.CONFIRMATION);

    ButtonType yes = new ButtonType("Yes");

    ButtonType no = new ButtonType("No");
   
    
    
    
     
    
    @FXML
    public void handleButtonAction(ActionEvent ev) throws IOException
    {
        //Exit Button
           if( ev.getSource() == eBtn){
              System.exit(0);
            }
          
         //PRODUCT METHODS
         //modify product  
           if( ev.getSource() == proModBtn){

               changeScene("ModifyProductScreen", ev);
            }
           
         //add product  
           if( ev.getSource() == proAddBtn){
              
              changeScene("AddProductScreen", ev);
            }
           
         //delete product 
           if(ev.getSource() == proDelBtn){
        
            Optional<ButtonType> answer = delAlert.showAndWait();
            if (answer.get() == yes) {
                 Product selectedProduct = (Product) proTableView.getSelectionModel().getSelectedItem();
                 i1.deleteProduct(selectedProduct);
            } else {}
            
           }
           
           //search product
            if (ev.getSource() == proSBtn) {

               //search by id
               if (proTF.getText().matches(".*\\d.*")) {
                   Product p1 = i1.lookupProduct(Integer.parseInt(proTF.getText()));

                   ObservableList<Product> searchResult = FXCollections.observableArrayList();
                   searchResult.add(p1);

                   proTableView.setItems(searchResult);

                //clear search    
            } else if (proTF.getText().equals("")) {
                proTableView.setItems(i1.getAllProducts());

                //search by name
            } else {
                proTableView.setItems(i1.lookupProduct(proTF.getText()));
            }
        }
          
         //PART METHODS
         //modify part screen
           if( ev.getSource() == prtModBtn){
              
              changeScene("ModifyPartScreen", ev);
            }
             
         //add part screen 
           if( ev.getSource() == prtAddBtn){
               
               changeScene("AddPartScreen", ev);
            }
           
         //delete part 
           if (ev.getSource() == prtDelBtn) {

            Optional<ButtonType> answer = delAlert.showAndWait();
            if (answer.get() == yes) {
                Part selectedPart = (Part) partTableView.getSelectionModel().getSelectedItem();
                i1.deletePart(selectedPart);
            } else {
            }

        }
            
        //search part
            if (ev.getSource() == prtSBtn) {

               //search by id
               if (prtTF.getText().matches(".*\\d.*")) {
                   Part p1 = i1.lookupPart(Integer.parseInt(prtTF.getText()));

                   ObservableList<Part> searchResult = FXCollections.observableArrayList();
                   searchResult.add(p1);

                   partTableView.setItems(searchResult);

                //clear search    
            } else if (prtTF.getText().equals("")) {
                partTableView.setItems(i1.getAllParts());

                //search by name
            } else {
                partTableView.setItems(i1.lookupPart(prtTF.getText()));
            }
        }
    }
    
    public void changeScene(String screenName, ActionEvent ev) throws IOException{
       
        String fileName = screenName + ".fxml";
       
        //add part screen setup
        switch (screenName) {
            case "AddPartScreen":
                {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("" + fileName + ""));
                    Parent parentName = fxmlLoader.load();
                    Scene sceneName = new Scene(parentName);
                    AddPartScreenController addPartScreen = fxmlLoader.getController();
                    addPartScreen.setList(i1.getAllParts());
                    Stage oldWindow = (Stage) ((Node) ev.getSource()).getScene().getWindow();
                    addPartScreen.getOldWindow(oldWindow);
                    Stage window = new Stage();
                    window.setScene(sceneName);
                    window.show();
                    
                    
                    break;
                }
            case "ModifyPartScreen":
                {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("" + fileName + ""));
                   
                    Parent parentName = (Parent) fxmlLoader.load();
                    Scene sceneName = new Scene(parentName);
      
                    ModifyPartScreenController modifyPartScreen = fxmlLoader.getController();
                    modifyPartScreen.setSelected(partTableView.getSelectionModel().getSelectedIndex(), partTableView.getSelectionModel().getSelectedItem());
                    modifyPartScreen.setList(i1.getAllParts());
                    //send current mainscreen
                    Stage oldWindow = (Stage) ((Node) ev.getSource()).getScene().getWindow();
                    modifyPartScreen.getOldWindow(oldWindow);
                    Stage window = new Stage();
                    window.setScene(sceneName);
                    window.show();
                    break;
                }
                 case "AddProductScreen":
                {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("" + fileName + ""));
                   
                    Parent parentName = (Parent) fxmlLoader.load();
                    Scene sceneName = new Scene(parentName);
      
                    AddProductScreenController addProductScreen = fxmlLoader.getController();
                    addProductScreen.setProducts(i1.getAllProducts());
                    addProductScreen.setParts(i1.getAllParts());
                    Stage oldWindow = (Stage) ((Node) ev.getSource()).getScene().getWindow();
                    addProductScreen.getOldWindow(oldWindow);
                    Stage window = new Stage();
                    window.setScene(sceneName);
                    window.show();
                    
                    break;
                }
                 case "ModifyProductScreen":
                {
                   
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("" + fileName + ""));
                   
                    Parent parentName = (Parent) fxmlLoader.load();
                    Scene sceneName = new Scene(parentName);
      
                    ModifyProductScreenController modifyProductScreen = fxmlLoader.getController();
                    modifyProductScreen.setSelected(proTableView.getSelectionModel().getSelectedIndex(), proTableView.getSelectionModel().getSelectedItem());
                    modifyProductScreen.setParts(i1.getAllParts());
                    modifyProductScreen.setList(i1.getAllProducts());

                    
                    //send current mainscreen
                    Stage oldWindow = (Stage) ((Node) ev.getSource()).getScene().getWindow();
                    modifyProductScreen.getOldWindow(oldWindow);
                    Stage window = new Stage();
                    window.setScene(sceneName);
                    window.show();
                    break;
                }
        }
    }
    
    public Inventory getInv(){
        return i1;
    }
    
    public TableView getTableView(String tableViewType){
        if (tableViewType.contains("part")) {
            return partTableView;
        } else {
            return proTableView;
        }
    }
    
    public void setList(ObservableList aList){
        if(aList.toString().contains("InHouse") || (aList.toString().contains("Outsourced"))){
       
        ObservableList<Part> parts = aList;
        i1.getAllParts().clear();
        for (Part eachPart : parts){
            i1.addPart(eachPart);
    }
      
        partTableView.setItems(i1.getAllParts());
    } 
        else{
        ObservableList<Product> products = aList;
        i1.getAllProducts().clear();
        for (Product eachProduct : products){
            i1.addProduct(eachProduct);
    }
        proTableView.setItems(i1.getAllProducts());
        }
    }
    
    
    public void setTableView(TableView tableView, String tableViewType){
        if (tableViewType.contains("part")){

           tableView.setItems(i1.getAllParts());  
        }
        else 
           tableView.setItems(i1.getAllProducts());
    }
    
    public void addPartNewScreen(Part part){
        i1.addPart(part);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        ptIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        ptNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        ptInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ptPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        proIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        proNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        proInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        proPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        //SAMPLE data
        i1.addPart(new InHouse(1,"pt one",5.55,2,0,10,515));
        i1.addPart(new InHouse(2,"pt two",5.55,2,0,10,515));        
        i1.addPart(new InHouse(3,"pt three",5.55,2,0,10,515));  
        i1.addPart(new InHouse(4,"pt four",5.55,2,0,10,515));  
        
     
        i1.addProduct(new Product(1,"pro one",5.55,2,0,10));
        i1.addProduct(new Product(2,"pro two",5.55,2,0,10));        
        i1.addProduct(new Product(3,"pro three",5.55,2,0,10));  
        i1.addProduct(new Product(4,"pro four",5.55,2,0,10));    
        

        partTableView.setItems(i1.getAllParts());
        proTableView.setItems(i1.getAllProducts());
        
        
        delAlert.setTitle("Are You Sure?");
        delAlert.setHeaderText("Confirm cancellation or deletion");

        delAlert.getButtonTypes().setAll(yes, no);
    }
    }
    

