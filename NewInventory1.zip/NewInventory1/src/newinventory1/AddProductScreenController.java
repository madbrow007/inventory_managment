/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newinventory1;

import Business.*;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Madbr
 */
public class AddProductScreenController implements Initializable {

    @FXML
    private Button saveBtn;
    @FXML
    private Button cancelBtn;
    @FXML
    private TextField idTF;
    @FXML
    private TextField nameTF;
    @FXML
    private TextField invTF;
    @FXML
    private TextField pcTF;
    @FXML
    private TextField maxTF;
    @FXML
    private TextField minTF;
    @FXML
    private TextField proTF;
    @FXML
    private Button proAddBtn;
    @FXML
    private Button proDelBtn;
    @FXML
    private Button proSBtn;
    @FXML
    private TableView addPartTable;
    @FXML
    private TableView delPartTable;
    @FXML
    private TableColumn<Part, Integer> addIdCol;
    @FXML
    private TableColumn<Part, String> addNameCol;
    @FXML
    private TableColumn<Part, Integer> addInvCol;
    @FXML
    private TableColumn<Part, Double> addPriceCol;
    @FXML
    private TableColumn<Part, Integer> delIdCol;
    @FXML
    private TableColumn<Part, String> delNameCol;
    @FXML
    private TableColumn<Part, Integer> delInvCol;
    @FXML
    private TableColumn<Part, Double> delPriceCol;
    
    private Inventory i1 = new Inventory();
    
    private Product p1 = new Product();

    private Stage oldWindow;

    Alert minAlert = new Alert(AlertType.ERROR);

    Alert delAlert = new Alert(Alert.AlertType.CONFIRMATION);

    ButtonType yes = new ButtonType("Yes");

    ButtonType no = new ButtonType("No");



    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        addNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        addInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        delIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        delNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        delInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        delPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        
   
        minAlert.setTitle("Error Dialog");
        minAlert.setHeaderText("Minimum exceeds Maximum Error!");
        minAlert.setContentText("The minimum field entered is greater than the maximum field! Please enter smaller value!");
        
        delAlert.setTitle("Are You Sure?");
        delAlert.setHeaderText("Confirm cancellation or deletion");

        delAlert.getButtonTypes().setAll(yes, no);
    }    
    
      @FXML
    public void handleButtonAction(ActionEvent ev) throws IOException
    {
         if( ev.getSource() == cancelBtn){
              Optional<ButtonType> answer = delAlert.showAndWait();
              if (answer.get() == yes){
              Stage window = (Stage) ((Node) ev.getSource()).getScene().getWindow();
              window.close();
            }
              else{}
           }
         
         if(ev.getSource() == saveBtn){
                   
                   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
                    
                   Parent parentName = fxmlLoader.load();
                    
                   Scene sceneName = new Scene(parentName);
                   
                   FXMLDocumentController mainScreen = fxmlLoader.getController();
                  
                   int current = 0;
                   int next = 0;
                   for (Product eachProduct : i1.getAllProducts()){
                       if (eachProduct.getId() > current){
                           current = eachProduct.getId();
                       }
                    }
                   
                   int id = current + 1;
                        
                   
                   p1.setId(id);
                   p1.setName(nameTF.getText());
                   p1.setStock(Integer.parseInt(invTF.getText()));
                   p1.setPrice(Double.parseDouble(pcTF.getText()));
                   p1.setMax(Integer.parseInt(maxTF.getText()));
                   p1.setMin(Integer.parseInt(minTF.getText()));
                   
                   if (p1.getMin() > p1.getMax()){
                       minAlert.showAndWait();
                   }
                   else{
              
                   i1.addProduct(p1);
                   mainScreen.setList(i1.getAllProducts());
                
                   oldWindow.close();
                   
                   Stage window = (Stage)((Node)ev.getSource()).getScene().getWindow();
                   window.setScene(sceneName);
                   window.show();
                   }
               }      
         
         if(ev.getSource() == proAddBtn){
             Part selectedPart = (Part) addPartTable.getSelectionModel().getSelectedItem();
             p1.addAssociatedPart(selectedPart);
             delPartTable.setItems(p1.getAllAssociatedParts());
         }
          //search Parts
            if (ev.getSource() == proSBtn) {

               //search by id
               if (proTF.getText().matches(".*\\d.*")) {
                   Part p1 = i1.lookupPart(Integer.parseInt(proTF.getText()));

                   ObservableList<Part> searchResult = FXCollections.observableArrayList();
                   searchResult.add(p1);

                   addPartTable.setItems(searchResult);

                //clear search    
            } else if (proTF.getText().equals("")) {
                addPartTable.setItems(i1.getAllParts());

                //search by name
            } else {
                addPartTable.setItems(i1.lookupProduct(proTF.getText()));
            }
        }
            
        if(ev.getSource() == proDelBtn){
              Optional<ButtonType> answer = delAlert.showAndWait();
              if (answer.get() == yes){
              Part selectedPart = (Part) delPartTable.getSelectionModel().getSelectedItem();
              p1.deleteAssociatedPart(selectedPart);
            }
              else{}
        }
    }
         
    public void setProducts(ObservableList<Product> newAllProducts){
        for (Product eachProduct : newAllProducts){
            
            i1.addProduct(eachProduct);
        }
    }
    
    public void setParts(ObservableList<Part> allParts){
        for (Part eachPart : allParts){
            
            i1.addPart(eachPart);
        }
        addPartTable.setItems(i1.getAllParts());  
    }
    
   public void getOldWindow(Stage window){
         oldWindow = window;
     } 
}
    
 
